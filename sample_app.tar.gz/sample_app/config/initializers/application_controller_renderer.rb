# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '825799031d4f00c80ace0c4d49d1a7c3487ccde466693d0fb9183a46c22829df1ee4e50db059a272a7e1a5ecfd90f2d80e50291ef29e874b8356fa8486d8eed4'